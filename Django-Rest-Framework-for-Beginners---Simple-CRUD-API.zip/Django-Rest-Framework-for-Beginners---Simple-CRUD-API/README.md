# Django-Rest-Framework-for-Beginners---Simple-CRUD-API
Django-Rest-Frameworkni endi boshlayotganlar uchun sodda CRUD API project
