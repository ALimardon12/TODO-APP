from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Sample data to store TODO items
todo_list = []


@app.route("/")
def index():
    return render_template("index.html", todo_list=todo_list)


@app.route("/add", methods=["POST"])
def add():
    task = request.form.get("task")
    if task:
        todo_list.append(task)
    return redirect(url_for("index"))


@app.route("/update/<int:index>", methods=["GET", "POST"])
def update(index):
    if request.method == "POST":
        new_task = request.form.get("new_task")
        if new_task:
            todo_list[index] = new_task
        return redirect(url_for("index"))
    return render_template("update.html", index=index, task=todo_list[index])


@app.route("/delete/<int:index>")
def delete(index):
    if 0 <= index < len(todo_list):
        todo_list.pop(index)
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(debug=True)
