from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional

app = FastAPI()

class Task(BaseModel):
    title: str
    description: Optional[str] = None

# Sample data to store TODO items
todo_list = []

@app.post("/tasks/", response_model=Task)
def create_task(task: Task):
    todo_list.append(task)
    return task

@app.get("/tasks/", response_model=List[Task])
def read_tasks():
    return todo_list

@app.get("/tasks/{task_id}", response_model=Task)
def read_task(task_id: int):
    try:
        return todo_list[task_id]
    except IndexError:
        raise HTTPException(status_code=404, detail="Task not found")

@app.put("/tasks/{task_id}", response_model=Task)
def update_task(task_id: int, task: Task):
    try:
        todo_list[task_id] = task
        return task
    except IndexError:
        raise HTTPException(status_code=404, detail="Task not found")

@app.delete("/tasks/{task_id}", response_model=Task)
def delete_task(task_id: int):
    try:
        deleted_task = todo_list.pop(task_id)
        return deleted_task
    except IndexError:
        raise HTTPException(status_code=404, detail="Task not found")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
